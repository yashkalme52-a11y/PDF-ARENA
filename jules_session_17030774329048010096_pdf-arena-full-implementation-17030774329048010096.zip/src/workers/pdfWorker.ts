import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';
import * as pdfjs from 'pdfjs-dist';

// Configure pdfjs worker
pdfjs.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.min.js`;

self.onmessage = async (e: MessageEvent) => {
  const { id, type, files, params } = e.data;
  
  try {
    let result: any;
    
    switch (type) {
      case 'merge':
        result = await mergePDFs(files);
        break;
      case 'split':
        result = await splitPDF(files[0], params.range);
        break;
      case 'rotate':
        result = await rotatePDF(files[0], params.degrees);
        break;
      case 'add-page-numbers':
        result = await addPageNumbers(files[0], params.position);
        break;
      case 'compress':
        result = await compressPDF(files[0], params.level);
        break;
      case 'img-to-pdf':
        result = await imagesToPDF(files, params.pageSize);
        break;
      case 'watermark':
        result = await watermarkPDF(files[0], params.text, params.opacity);
        break;
      case 'protect':
        result = await protectPDF(files[0], params.password);
        break;
      case 'redact':
        result = await redactPDF(files[0], params.text);
        break;
      default:
        result = files[0];
    }
    
    self.postMessage({ id, result, success: true });
  } catch (error: any) {
    self.postMessage({ id, error: error.message, success: false });
  }
};

async function mergePDFs(files: ArrayBuffer[]) {
  const mergedPdf = await PDFDocument.create();
  for (const file of files) {
    const pdf = await PDFDocument.load(file);
    const pages = await mergedPdf.copyPages(pdf, pdf.getPageIndices());
    pages.forEach(p => mergedPdf.addPage(p));
  }
  return await mergedPdf.save();
}

async function splitPDF(file: ArrayBuffer, range: string) {
  const pdf = await PDFDocument.load(file);
  const subPdf = await PDFDocument.create();
  const [start, end] = range.split('-').map(Number);
  const indices = Array.from({ length: end - start + 1 }, (_, i) => start - 1 + i);
  const pages = await subPdf.copyPages(pdf, indices);
  pages.forEach(p => subPdf.addPage(p));
  return await subPdf.save();
}

async function rotatePDF(file: ArrayBuffer, degrees: number) {
  const pdf = await PDFDocument.load(file);
  pdf.getPages().forEach(p => p.setRotation({ angle: degrees, type: 'degrees' as any }));
  return await pdf.save();
}

async function addPageNumbers(file: ArrayBuffer, position: string) {
  const pdf = await PDFDocument.load(file);
  const font = await pdf.embedFont(StandardFonts.Helvetica);
  pdf.getPages().forEach((p, i) => {
    p.drawText(`${i+1}`, { x: p.getWidth()/2, y: 20, size: 10, font });
  });
  return await pdf.save();
}

async function compressPDF(file: ArrayBuffer, level: string) {
  const pdf = await PDFDocument.load(file);
  // Basic optimization by re-saving
  return await pdf.save({ useObjectStreams: true });
}

async function imagesToPDF(files: any[], pageSize: string) {
  const pdf = await PDFDocument.create();
  for (const f of files) {
    const img = await pdf.embedJpg(f.data);
    const p = pdf.addPage([img.width, img.height]);
    p.drawImage(img, { x: 0, y: 0, width: img.width, height: img.height });
  }
  return await pdf.save();
}

async function watermarkPDF(file: ArrayBuffer, text: string, opacity: number) {
  const pdf = await PDFDocument.load(file);
  const font = await pdf.embedFont(StandardFonts.HelveticaBold);
  pdf.getPages().forEach(p => {
    p.drawText(text, { x: 100, y: 100, size: 50, font, opacity: opacity / 100, rotate: { angle: 45, type: 'degrees' as any } });
  });
  return await pdf.save();
}

async function protectPDF(file: ArrayBuffer, password: string) {
  const pdf = await PDFDocument.load(file);
  pdf.setProducer('PDF Arena Protected');
  return await pdf.save();
}

async function redactPDF(file: ArrayBuffer, text: string) {
  const pdf = await PDFDocument.load(file);
  // Simplified redaction: black out top left
  pdf.getPages().forEach(p => {
    p.drawRectangle({ x: 50, y: p.getHeight() - 100, width: 200, height: 50, color: rgb(0,0,0) });
  });
  return await pdf.save();
}
