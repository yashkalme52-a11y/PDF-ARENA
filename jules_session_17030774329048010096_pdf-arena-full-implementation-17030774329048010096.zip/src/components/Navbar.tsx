import React from 'react';
import { Link } from 'react-router-dom';
import { FileText, Trophy, LayoutDashboard, CreditCard, ShieldCheck } from 'lucide-react';

export const Navbar = () => {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-white/5">
      <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 group">
          <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center group-hover:rotate-12 transition-transform">
            <FileText className="text-white" />
          </div>
          <span className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary via-secondary to-accent">
            PDF Arena
          </span>
        </Link>
        
        <div className="hidden md:flex items-center gap-8">
          <NavLink to="/leaderboard" icon={<Trophy size={18} />} label="Leaderboard" />
          <NavLink to="/dashboard" icon={<LayoutDashboard size={18} />} label="Dashboard" />
          <NavLink to="/pricing" icon={<CreditCard size={18} />} label="Pricing" />
          <NavLink to="/admin" icon={<ShieldCheck size={18} />} label="Admin" />
        </div>
      </div>
    </nav>
  );
};

const NavLink = ({ to, icon, label }: { to: string, icon: React.ReactNode, label: string }) => (
  <Link to={to} className="flex items-center gap-2 text-white/70 hover:text-white transition-colors">
    {icon}
    <span className="font-medium">{label}</span>
  </Link>
);
