import React from 'react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const Card = ({ children, className }: { children: React.ReactNode, className?: string }) => (
  <div className={cn("bg-white/5 backdrop-blur-lg border border-white/10 rounded-2xl p-6 overflow-hidden", className)}>
    {children}
  </div>
);

export const Button = ({ children, className, variant = 'primary', ...props }: any) => {
  const variants = {
    primary: "bg-primary hover:bg-primary/80 text-white shadow-[0_0_15px_rgba(99,102,241,0.4)]",
    secondary: "bg-secondary hover:bg-secondary/80 text-white shadow-[0_0_15px_rgba(168,85,247,0.4)]",
    accent: "bg-accent hover:bg-accent/80 text-white shadow-[0_0_15px_rgba(6,182,212,0.4)]",
    outline: "border border-white/20 hover:bg-white/10 text-white",
  };
  
  return (
    <button 
      className={cn("px-6 py-3 rounded-xl font-semibold transition-all active:scale-95 disabled:opacity-50", (variants as any)[variant], className)}
      {...props}
    >
      {children}
    </button>
  );
};
