export type ToolId = 
  | 'merge' | 'split' | 'compress' | 'pdf-to-img' | 'img-to-pdf' 
  | 'watermark' | 'page-numbers' | 'rotate' | 'protect' | 'unlock' 
  | 'redact' | 'compare' | 'fill-form'
  | 'pdf-to-word' | 'word-to-pdf' | 'pdf-to-excel' | 'ocr' | 'repair';

export interface ToolInfo {
  id: ToolId;
  name: string;
  description: string;
  isPro?: boolean;
  isComingSoon?: boolean;
}

export interface UserStats {
  pdfsProcessed: number;
  votesCast: number;
  downloads: number;
  currentPlan: 'FREE' | 'PRO' | 'ENTERPRISE';
  dailyUsage: number;
}

export interface EloScore {
  traditional: number;
  ai: number;
}

export interface HistoryItem {
  id: string;
  toolId: ToolId;
  timestamp: number;
  filename: string;
  traditionalUrl: string;
  aiUrl: string;
  votedFor?: 'traditional' | 'ai';
}

export interface Achievement {
  id: string;
  name: string;
  description: string;
  unlocked: boolean;
  icon: string;
}
