import React, { createContext, useContext, useState, useEffect } from 'react';
import { ToolId, EloScore, HistoryItem, UserStats } from '../types';

interface AppState {
  geminiKey: string | null;
  eloScores: Record<ToolId, EloScore>;
  history: HistoryItem[];
  stats: UserStats;
  setGeminiKey: (key: string) => void;
  updateElo: (toolId: ToolId, winner: 'traditional' | 'ai') => void;
  addHistory: (item: HistoryItem) => void;
  incrementStats: (type: keyof Omit<UserStats, 'currentPlan'>) => void;
}

const DEFAULT_ELO = 1500;

const AppContext = createContext<AppState | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [geminiKey, setGeminiKeyInternal] = useState<string | null>(() => localStorage.getItem('gemini_key'));
  const [eloScores, setEloScores] = useState<Record<ToolId, EloScore>>(() => {
    const saved = localStorage.getItem('elo_scores');
    return saved ? JSON.parse(saved) : {};
  });
  const [history, setHistory] = useState<HistoryItem[]>(() => {
    const saved = localStorage.getItem('history');
    return saved ? JSON.parse(saved) : [];
  });
  const [stats, setStats] = useState<UserStats>(() => {
    const saved = localStorage.getItem('user_stats');
    return saved ? JSON.parse(saved) : {
      pdfsProcessed: 0,
      votesCast: 0,
      downloads: 0,
      currentPlan: 'FREE',
      dailyUsage: 0
    };
  });

  useEffect(() => {
    localStorage.setItem('elo_scores', JSON.stringify(eloScores));
  }, [eloScores]);

  useEffect(() => {
    localStorage.setItem('history', JSON.stringify(history));
  }, [history]);

  useEffect(() => {
    localStorage.setItem('user_stats', JSON.stringify(stats));
  }, [stats]);

  const setGeminiKey = (key: string) => {
    setGeminiKeyInternal(key);
    localStorage.setItem('gemini_key', key);
  };

  const updateElo = (toolId: ToolId, winner: 'traditional' | 'ai') => {
    setEloScores(prev => {
      const current = prev[toolId] || { traditional: DEFAULT_ELO, ai: DEFAULT_ELO };
      const K = 32;
      const expectedT = 1 / (1 + 10 ** ((current.ai - current.traditional) / 400));
      const expectedA = 1 / (1 + 10 ** ((current.traditional - current.ai) / 400));
      
      const newT = winner === 'traditional' ? current.traditional + K * (1 - expectedT) : current.traditional + K * (0 - expectedT);
      const newA = winner === 'ai' ? current.ai + K * (1 - expectedA) : current.ai + K * (0 - expectedA);
      
      return { ...prev, [toolId]: { traditional: Math.round(newT), ai: Math.round(newA) } };
    });
    incrementStats('votesCast');
  };

  const addHistory = (item: HistoryItem) => {
    setHistory(prev => [item, ...prev].slice(0, 50));
    incrementStats('pdfsProcessed');
  };

  const incrementStats = (type: keyof Omit<UserStats, 'currentPlan'>) => {
    setStats(prev => ({ ...prev, [type]: prev[type] + 1 }));
  };

  return (
    <AppContext.Provider value={{ geminiKey, eloScores, history, stats, setGeminiKey, updateElo, addHistory, incrementStats }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
};
