import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AppProvider } from './store/AppContext';
import { Navbar } from './components/Navbar';

import { LandingPage } from './pages/LandingPage';
import { ToolPage } from './pages/ToolPage';
import { LeaderboardPage } from './pages/LeaderboardPage';
import { DashboardPage } from './pages/DashboardPage';
import { PricingPage } from './pages/PricingPage';
import { AdminDashboard } from './pages/AdminDashboard';

// Placeholder Pages

function App() {
  return (
    <AppProvider>
      <Router>
        <div className="min-h-screen bg-background text-white selection:bg-primary/30">
          <Navbar />
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/tool/:id" element={<ToolPage />} />
            <Route path="/leaderboard" element={<LeaderboardPage />} />
            <Route path="/dashboard" element={<DashboardPage />} />
            <Route path="/pricing" element={<PricingPage />} />
            <Route path="/admin" element={<AdminDashboard />} />
          </Routes>
        </div>
      </Router>
    </AppProvider>
  );
}

export default App;
