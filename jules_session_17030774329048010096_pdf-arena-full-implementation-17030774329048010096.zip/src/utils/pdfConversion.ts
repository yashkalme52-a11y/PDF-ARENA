import { PDFDocument } from 'pdf-lib';
// Note: pdfjs-dist is typically used in the browser for PDF to Image conversion
// We'll define the interface here, and implementation will use the global pdfjs if needed or be browser-only.

export const compressPDF = async (file: ArrayBuffer, level: 'low' | 'medium' | 'high'): Promise<Uint8Array> => {
  const pdf = await PDFDocument.load(file);
  // pdf-lib doesn't have native high-level compression (like image downsampling)
  // but we can "copy" to a new doc which often removes unused objects
  const compressedPdf = await PDFDocument.create();
  const copiedPages = await compressedPdf.copyPages(pdf, pdf.getPageIndices());
  copiedPages.forEach(p => compressedPdf.addPage(p));
  
  // In a real production app, we might use a worker to downsample images.
  // For now, we use the save options.
  return await compressedPdf.save({ useObjectStreams: true });
};

export const imagesToPDF = async (images: { data: ArrayBuffer, type: 'jpg' | 'png' | 'webp' }[], pageSize: 'A4' | 'Letter' | 'Fit'): Promise<Uint8Array> => {
  const pdf = await PDFDocument.create();
  
  for (const imgData of images) {
    let embeddedImg;
    if (imgData.type === 'jpg') {
      embeddedImg = await pdf.embedJpg(imgData.data);
    } else {
      embeddedImg = await pdf.embedPng(imgData.data);
    }
    
    const { width, height } = embeddedImg.scale(1);
    const page = pdf.addPage([width, height]);
    page.drawImage(embeddedImg, {
      x: 0,
      y: 0,
      width,
      height,
    });
  }
  
  return await pdf.save();
};

// pdfToImages will be implemented in a component/worker because it requires pdfjs-dist and Canvas
