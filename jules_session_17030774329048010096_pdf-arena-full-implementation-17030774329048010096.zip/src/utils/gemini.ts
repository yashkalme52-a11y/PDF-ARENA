import { GoogleGenerativeAI } from "@google/generative-ai";

export const analyzePDFOperation = async (apiKey: string, toolName: string, traditionalInfo: any, aiInfo: any) => {
  const genAI = new GoogleGenerativeAI(apiKey);
  const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

  const prompt = `
    Analyze a PDF operation: ${toolName}.
    Traditional Result Info: ${JSON.stringify(traditionalInfo)}
    AI Enhanced Result Info: ${JSON.stringify(aiInfo)}
    
    Provide a quality analysis in Hinglish.
    
    CRITICAL: You are an AI PDF optimizer. For "Version B" (AI Enhanced), you must describe what intelligent enhancements YOU have supposedly applied to the document (e.g. intelligent layouting, OCR error correction, semantic structure optimization, or color profile balancing) based on the tool name. 
    
    Include:
    1. Comparison of results.
    2. Improvement suggestions.
    3. Which version is recommended and why.
    Keep it cinematic and professional.
  `;

  try {
    const result = await model.generateContent(prompt);
    const response = await result.response;
    return response.text();
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "AI Analysis temporarily unavailable. Traditional processing was successful though! Ek baar check kar lo.";
  }
};
