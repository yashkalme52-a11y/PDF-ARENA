import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';

export const mergePDFs = async (files: ArrayBuffer[]): Promise<Uint8Array> => {
  const mergedPdf = await PDFDocument.create();
  for (const file of files) {
    const pdf = await PDFDocument.load(file);
    const copiedPages = await mergedPdf.copyPages(pdf, pdf.getPageIndices());
    copiedPages.forEach((page) => mergedPdf.addPage(page));
  }
  return await mergedPdf.save();
};

export const splitPDF = async (file: ArrayBuffer, range: string): Promise<Uint8Array[]> => {
  const pdf = await PDFDocument.load(file);
  const results: Uint8Array[] = [];
  
  // Simple range parser: "1,2,3-5"
  const ranges = range.split(',').map(r => r.trim());
  for (const r of ranges) {
    const subPdf = await PDFDocument.create();
    if (r.includes('-')) {
      const [start, end] = r.split('-').map(Number);
      const indices = Array.from({ length: end - start + 1 }, (_, i) => start - 1 + i);
      const copiedPages = await subPdf.copyPages(pdf, indices);
      copiedPages.forEach(p => subPdf.addPage(p));
    } else {
      const idx = Number(r) - 1;
      const copiedPages = await subPdf.copyPages(pdf, [idx]);
      copiedPages.forEach(p => subPdf.addPage(p));
    }
    results.push(await subPdf.save());
  }
  return results;
};

export const rotatePDF = async (file: ArrayBuffer, degrees: number, pageIndices?: number[]): Promise<Uint8Array> => {
  const pdf = await PDFDocument.load(file);
  const pages = pdf.getPages();
  const indices = pageIndices || pages.map((_, i) => i);
  
  indices.forEach(idx => {
    const page = pages[idx];
    const currentRotation = page.getRotation().angle;
    page.setRotation({ angle: (currentRotation + degrees) % 360, type: 'degrees' as any });
  });
  
  return await pdf.save();
};

export const addPageNumbers = async (file: ArrayBuffer, position: 'bottom-center' | 'bottom-right' | 'top-center'): Promise<Uint8Array> => {
  const pdf = await PDFDocument.load(file);
  const pages = pdf.getPages();
  const font = await pdf.embedFont(StandardFonts.Helvetica);
  
  pages.forEach((page, i) => {
    const { width, height } = page.getSize();
    const text = `${i + 1} / ${pages.length}`;
    const textSize = 10;
    const textWidth = font.widthOfTextAtSize(text, textSize);
    
    let x = width / 2 - textWidth / 2;
    let y = 20;
    
    if (position === 'bottom-right') {
      x = width - textWidth - 20;
    } else if (position === 'top-center') {
      y = height - 30;
    }
    
    page.drawText(text, { x, y, size: textSize, font, color: rgb(0.5, 0.5, 0.5) });
  });
  
  return await pdf.save();
};
