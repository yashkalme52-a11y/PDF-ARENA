import React from 'react';
import { Hero3D } from '../components/Hero3D';
import { Button, Card } from '../components/UI';
import { ToolId, ToolInfo } from '../types';
import { 
  Merge, Scissors, Zap, Image as ImageIcon, FileImage, 
  Type, Hash, RotateCw, Shield, Unlock, Eraser, Columns, FormInput 
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

const TOOLS: ToolInfo[] = [
  { id: 'merge', name: 'Merge PDF', description: 'Combine multiple PDFs into one.' },
  { id: 'split', name: 'Split PDF', description: 'Split PDF into multiple files.' },
  { id: 'compress', name: 'Compress PDF', description: 'Reduce PDF file size.' },
  { id: 'pdf-to-img', name: 'PDF to Image', description: 'Convert PDF pages to JPG/PNG.' },
  { id: 'img-to-pdf', name: 'Image to PDF', description: 'Convert images to PDF.' },
  { id: 'watermark', name: 'Watermark', description: 'Add text watermark to PDF.' },
  { id: 'page-numbers', name: 'Page Numbers', description: 'Add page numbers easily.' },
  { id: 'rotate', name: 'Rotate PDF', description: 'Rotate one or all pages.' },
  { id: 'protect', name: 'Protect PDF', description: 'Encrypt PDF with password.' },
  { id: 'unlock', name: 'Unlock PDF', description: 'Remove PDF password.' },
  { id: 'redact', name: 'Redact PDF', description: 'Hide sensitive info.' },
  { id: 'compare', name: 'Compare PDFs', description: 'Find differences side-by-side.' },
  { id: 'fill-form', name: 'Fill Form', description: 'Fill PDF form fields.' },
];

const ICON_MAP: Record<string, any> = {
  merge: Merge, split: Scissors, compress: Zap, 'pdf-to-img': ImageIcon,
  'img-to-pdf': FileImage, watermark: Type, 'page-numbers': Hash,
  rotate: RotateCw, protect: Shield, unlock: Unlock, redact: Eraser,
  compare: Columns, 'fill-form': FormInput
};

const COMING_SOON: ToolInfo[] = [
  { id: 'pdf-to-word', name: 'PDF to Word', description: 'Coming Soon', isPro: true, isComingSoon: true },
  { id: 'word-to-pdf', name: 'Word to PDF', description: 'Coming Soon', isPro: true, isComingSoon: true },
  { id: 'pdf-to-excel', name: 'PDF to Excel', description: 'Coming Soon', isPro: true, isComingSoon: true },
  { id: 'ocr', name: 'OCR PDF', description: 'Coming Soon', isPro: true, isComingSoon: true },
  { id: 'repair', name: 'Repair PDF', description: 'Coming Soon', isPro: true, isComingSoon: true },
];

export const LandingPage = () => {
  return (
    <div className="pb-20">
      <Hero3D />
      
      <div className="max-w-7xl mx-auto px-6 -mt-20 relative z-10">
        <div className="text-center mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-5xl md:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-primary via-white to-secondary"
          >
            The Ultimate PDF Battleground
          </motion.h2>
          <p className="text-white/60 text-xl max-w-2xl mx-auto">
            Process your PDFs with traditional precision or AI-powered intelligence.
            Vote for the winner and shape the future of PDF Arena.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {TOOLS.map((tool, index) => (
            <Link key={tool.id} to={`/tool/${tool.id}`}>
              <ToolCard tool={tool} index={index} />
            </Link>
          ))}
          {COMING_SOON.map((tool, index) => (
            <ToolCard key={tool.id} tool={tool} index={index + TOOLS.length} />
          ))}
        </div>
        
        <StatsSection />
      </div>
    </div>
  );
};

const ToolCard = ({ tool, index }: { tool: ToolInfo, index: number }) => {
  const Icon = ICON_MAP[tool.id] || Zap;
  
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      whileInView={{ opacity: 1, scale: 1 }}
      transition={{ delay: index * 0.05 }}
      whileHover={{ y: -10, scale: 1.02 }}
      className={`group relative h-full`}
    >
      <Card className="h-full group-hover:border-primary/50 transition-colors">
        {tool.isPro && (
          <div className="absolute top-4 right-4 bg-secondary/20 text-secondary text-[10px] font-bold px-2 py-1 rounded-full border border-secondary/30">
            PRO
          </div>
        )}
        <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
          <Icon className="text-white group-hover:text-primary transition-colors" />
        </div>
        <h3 className="text-xl font-bold mb-2">{tool.name}</h3>
        <p className="text-white/40 text-sm">{tool.description}</p>
        {tool.isComingSoon && (
          <div className="mt-4 text-[10px] font-bold tracking-widest text-white/20">COMING SOON</div>
        )}
      </Card>
    </motion.div>
  );
};

const StatsSection = () => (
  <div className="mt-32 grid grid-cols-2 md:grid-cols-4 gap-8">
    {[
      { label: 'PDFs Processed', value: '1M+' },
      { label: 'Votes Cast', value: '500K+' },
      { label: 'Tools Available', value: '18' },
      { label: 'Countries', value: '50+' },
    ].map((stat, i) => (
      <div key={i} className="text-center">
        <div className="text-4xl md:text-5xl font-black text-primary mb-2">{stat.value}</div>
        <div className="text-white/40 uppercase tracking-widest text-xs">{stat.label}</div>
      </div>
    ))}
  </div>
);
