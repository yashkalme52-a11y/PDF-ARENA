import React from 'react';
import { useApp } from '../store/AppContext';
import { Card, Button, cn } from '../components/UI';
import { 
  FileText, Vote, Download, Award, Clock, Star, 
  Zap, Shield, Flame, Target, Trophy, Medal
} from 'lucide-react';
import { motion } from 'framer-motion';

const ACHIEVEMENTS = [
  { id: 'first', name: 'First PDF', description: 'Process your first document', icon: FileText, unlocked: true },
  { id: 'voter', name: 'AI Voter', description: 'Cast 10 votes in the arena', icon: Vote, unlocked: false },
  { id: 'pro', name: 'Arena Pro', description: 'Process 100 documents', icon: Zap, unlocked: false },
  { id: 'streak', name: '7-Day Streak', description: 'Consistent processer', icon: Flame, unlocked: false },
  { id: 'champion', name: 'AI Champion', description: 'Vote for AI 50 times', icon: Trophy, unlocked: false },
  { id: 'master', name: 'Security Master', description: 'Protect 10 files', icon: Shield, unlocked: true },
];

export const DashboardPage = () => {
  const { stats, history } = useApp();

  return (
    <div className="pt-32 pb-20 px-6 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row items-end justify-between mb-12 gap-6">
        <div>
          <h2 className="text-4xl font-black mb-2">Welcome Back, Arena Master</h2>
          <p className="text-white/40 uppercase tracking-widest text-xs font-bold">Your Processing Command Center</p>
        </div>
        <div className="bg-primary/10 border border-primary/20 px-6 py-3 rounded-2xl flex items-center gap-3">
          <Star className="text-primary fill-primary" size={20} />
          <span className="font-bold text-primary">{stats.currentPlan} PLAN</span>
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        <StatCard icon={<FileText />} label="PDFs Processed" value={stats.pdfsProcessed} color="text-primary" />
        <StatCard icon={<Vote />} label="Votes Cast" value={stats.votesCast} color="text-secondary" />
        <StatCard icon={<Download />} label="Total Downloads" value={stats.downloads} color="text-accent" />
        <StatCard icon={<Award />} label="Daily Usage" value={`${stats.dailyUsage}/5`} color="text-success" />
      </div>

      <div className="grid lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2 space-y-12">
          <section>
            <h3 className="text-xl font-bold mb-6 flex items-center gap-3">
              <Clock className="text-white/40" /> Recent Activity
            </h3>
            <div className="space-y-4">
              {history.length === 0 ? (
                <div className="text-center py-20 glass rounded-3xl opacity-40">
                  <p>No activity yet. Go process some PDFs!</p>
                </div>
              ) : (
                history.map((item, i) => (
                  <motion.div 
                    key={item.id} 
                    initial={{ opacity: 0, x: -20 }} 
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.1 }}
                  >
                    <Card className="flex items-center justify-between py-4">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 bg-white/5 rounded-lg flex items-center justify-center">
                          <FileText size={20} className="text-primary" />
                        </div>
                        <div>
                          <div className="font-bold">{item.filename}</div>
                          <div className="text-[10px] text-white/40 uppercase tracking-widest">{item.toolId} • {new Date(item.timestamp).toLocaleString()}</div>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <a href={item.traditionalUrl} download>
                          <Button variant="outline" className="px-3 py-1.5 text-xs">Trad</Button>
                        </a>
                        <a href={item.aiUrl} download>
                          <Button variant="outline" className="px-3 py-1.5 text-xs border-secondary/40 text-secondary">AI</Button>
                        </a>
                      </div>
                    </Card>
                  </motion.div>
                ))
              )}
            </div>
          </section>
        </div>

        <section>
          <h3 className="text-xl font-bold mb-6 flex items-center gap-3">
            <Medal className="text-white/40" /> Achievements
          </h3>
          <div className="grid grid-cols-2 gap-4">
            {ACHIEVEMENTS.map((ach) => (
              <Card key={ach.id} className={cn(
                "p-4 flex flex-col items-center text-center transition-all",
                ach.unlocked ? "border-primary/30" : "opacity-30 grayscale"
              )}>
                <div className={cn(
                  "w-12 h-12 rounded-full flex items-center justify-center mb-3",
                  ach.unlocked ? "bg-primary/20 text-primary" : "bg-white/5 text-white"
                )}>
                  <ach.icon size={24} />
                </div>
                <div className="text-sm font-bold leading-tight mb-1">{ach.name}</div>
                <div className="text-[10px] text-white/40 uppercase tracking-tighter">{ach.description}</div>
              </Card>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

const StatCard = ({ icon, label, value, color }: any) => (
  <Card className="flex flex-col items-center text-center">
    <div className={cn("w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center mb-4", color)}>
      {React.cloneElement(icon, { size: 24 })}
    </div>
    <div className="text-3xl font-black mb-1">{value}</div>
    <div className="text-xs text-white/40 uppercase tracking-widest font-bold">{label}</div>
  </Card>
);
