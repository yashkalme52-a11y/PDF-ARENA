import React, { useState, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useDropzone } from 'react-dropzone';
import { Upload, File, Loader2, CheckCircle2, Trophy, ArrowLeft, Send, Zap } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button, Card, cn } from '../components/UI';
import { useApp } from '../store/AppContext';
import { mergePDFs, rotatePDF, addPageNumbers } from '../utils/pdfManipulation';
import { compressPDF, imagesToPDF } from '../utils/pdfConversion';
import { watermarkPDF, redactPDF, protectPDF, unlockPDF, fillPDFForm } from '../utils/pdfSecurity';
import { analyzePDFOperation } from '../utils/gemini';
import confetti from 'canvas-confetti';

export const ToolPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { geminiKey, setGeminiKey, updateElo, addHistory } = useApp();
  
  const [files, setFiles] = useState<File[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [results, setResults] = useState<{ traditional: string, ai: string, analysis: string } | null>(null);
  const [voted, setVoted] = useState<'traditional' | 'ai' | null>(null);
  const [tempApiKey, setTempApiKey] = useState('');

  const onDrop = useCallback((acceptedFiles: File[]) => {
    setFiles(prev => [...prev, ...acceptedFiles]);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ onDrop });

  if (!geminiKey) {
    return (
      <div className="pt-40 flex flex-col items-center justify-center px-6">
        <Card className="max-w-md w-full text-center">
          <Shield className="w-16 h-16 text-primary mx-auto mb-6" />
          <h2 className="text-3xl font-bold mb-4">Gemini API Setup</h2>
          <p className="text-white/60 mb-8">Enter your Gemini API key to unlock AI-powered PDF processing and analysis.</p>
          <input 
            type="password"
            value={tempApiKey}
            onChange={(e) => setTempApiKey(e.target.value)}
            placeholder="AIzaSy..."
            className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 mb-4 focus:ring-2 focus:ring-primary outline-none transition-all"
          />
          <Button 
            className="w-full" 
            onClick={() => setGeminiKey(tempApiKey)}
            disabled={!tempApiKey}
          >
            Save & Continue
          </Button>
        </Card>
      </div>
    );
  }

  const handleProcess = async () => {
    if (files.length === 0) return;
    setIsProcessing(true);
    
    try {
      const fileBuffers = await Promise.all(files.map(f => f.arrayBuffer()));
      let tradResult: Uint8Array;
      
      // Select tool logic based on ID
      switch (id) {
        case 'merge': tradResult = await mergePDFs(fileBuffers); break;
        case 'rotate': tradResult = await rotatePDF(fileBuffers[0], 90); break;
        case 'compress': tradResult = await compressPDF(fileBuffers[0], 'medium'); break;
        case 'watermark': tradResult = await watermarkPDF(fileBuffers[0], 'PDF ARENA', 50, 'center'); break;
        default: tradResult = new Uint8Array(fileBuffers[0]); // Fallback
      }

      const tradUrl = URL.createObjectURL(new Blob([tradResult as any], { type: 'application/pdf' }));
      
      // For demo, "AI Enhanced" just adds a watermark or metadata for now
      const aiResult = await watermarkPDF(tradResult.buffer as any, 'AI ENHANCED', 30, 'top');
      const aiUrl = URL.createObjectURL(new Blob([aiResult as any], { type: 'application/pdf' }));

      const analysis = await analyzePDFOperation(geminiKey, id || 'tool', { size: tradResult.length }, { size: aiResult.length });

      setResults({ traditional: tradUrl, ai: aiUrl, analysis });
      
      addHistory({
        id: Math.random().toString(36).substr(2, 9),
        toolId: id as any,
        timestamp: Date.now(),
        filename: files[0].name,
        traditionalUrl: tradUrl,
        aiUrl: aiUrl
      });

    } catch (error) {
      console.error(error);
      alert('Error processing PDF. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleVote = (winner: 'traditional' | 'ai') => {
    setVoted(winner);
    updateElo(id as any, winner);
    confetti({
      particleCount: 150,
      spread: 70,
      origin: { y: 0.6 },
      colors: winner === 'ai' ? ['#a855f7', '#6366f1'] : ['#06b6d4', '#6366f1']
    });
  };

  return (
    <div className="pt-32 pb-20 px-6 max-w-7xl mx-auto">
      <Button variant="outline" className="mb-8 gap-2" onClick={() => navigate('/')}>
        <ArrowLeft size={18} /> Back to Tools
      </Button>

      <div className="grid lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2 space-y-8">
          <AnimatePresence mode="wait">
            {!results ? (
              <motion.div
                key="upload"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
              >
                <div 
                  {...getRootProps()} 
                  className={cn(
                    "border-2 border-dashed rounded-3xl p-12 transition-all cursor-pointer flex flex-col items-center justify-center min-h-[400px]",
                    isDragActive ? "border-primary bg-primary/5 scale-105" : "border-white/10 hover:border-white/20 hover:bg-white/5"
                  )}
                >
                  <input {...getInputProps()} />
                  <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mb-6">
                    <Upload className={cn("w-10 h-10", isDragActive ? "text-primary animate-bounce" : "text-white/40")} />
                  </div>
                  <h3 className="text-2xl font-bold mb-2">Drag & Drop PDFs</h3>
                  <p className="text-white/40">or click to browse from your computer</p>
                </div>
                
                {files.length > 0 && (
                  <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-4">
                    {files.map((file, i) => (
                      <div key={i} className="glass p-4 rounded-xl flex items-center gap-3">
                        <File className="text-primary shrink-0" size={20} />
                        <span className="text-xs truncate">{file.name}</span>
                      </div>
                    ))}
                  </div>
                )}
              </motion.div>
            ) : (
              <motion.div
                key="results"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="grid md:grid-cols-2 gap-8"
              >
                <ResultCard 
                  type="traditional" 
                  url={results.traditional} 
                  winner={voted === 'traditional'} 
                  voted={!!voted}
                  onVote={() => handleVote('traditional')}
                />
                <ResultCard 
                  type="ai" 
                  url={results.ai} 
                  winner={voted === 'ai'} 
                  voted={!!voted}
                  onVote={() => handleVote('ai')}
                />
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="space-y-6">
          <Card>
            <h3 className="text-xl font-bold mb-4">Tool Settings</h3>
            <p className="text-white/40 text-sm mb-6 uppercase tracking-widest">Adjust parameters</p>
            {/* Tool-specific settings would go here */}
            <div className="space-y-4">
              <div className="p-4 bg-white/5 rounded-xl border border-white/5">
                <div className="text-sm font-medium mb-1">Quality Level</div>
                <div className="flex gap-2">
                  <button className="flex-1 py-2 bg-primary/20 text-primary border border-primary/30 rounded-lg text-sm">Standard</button>
                  <button className="flex-1 py-2 hover:bg-white/5 border border-white/10 rounded-lg text-sm transition-colors">High</button>
                </div>
              </div>
            </div>

            <Button 
              className="w-full mt-8 h-16 text-lg gap-3" 
              onClick={handleProcess}
              disabled={files.length === 0 || isProcessing}
            >
              {isProcessing ? <Loader2 className="animate-spin" /> : <Send size={20} />}
              {isProcessing ? 'Processing...' : 'Process Now'}
            </Button>
          </Card>

          {results && (
            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
              <Card className="border-secondary/30 bg-secondary/5">
                <div className="flex items-center gap-2 mb-4 text-secondary">
                  <Zap size={20} />
                  <h3 className="font-bold">AI Analysis (Hinglish)</h3>
                </div>
                <div className="text-sm leading-relaxed text-white/80 whitespace-pre-wrap">
                  {results.analysis}
                </div>
                {voted && (
                  <Button 
                    variant="secondary" 
                    className="w-full mt-6"
                    onClick={() => navigate('/leaderboard')}
                  >
                    View Leaderboard
                  </Button>
                )}
              </Card>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
};

const ResultCard = ({ type, url, winner, voted, onVote }: any) => {
  return (
    <Card className={cn(
      "relative group transition-all",
      type === 'traditional' ? "border-accent/20" : "border-secondary/20",
      winner && "border-success ring-4 ring-success/20 scale-105"
    )}>
      <div className={cn(
        "absolute top-0 left-0 w-full h-1",
        type === 'traditional' ? "bg-accent" : "bg-secondary"
      )} />
      
      <div className="flex items-center justify-between mb-4">
        <h4 className="font-bold uppercase tracking-widest text-xs opacity-60">
          {type === 'traditional' ? 'Traditional Result' : 'AI Enhanced'}
        </h4>
        {winner && <CheckCircle2 className="text-success" size={20} />}
      </div>
      
      <div className="aspect-[3/4] bg-white/5 rounded-xl mb-6 flex flex-col items-center justify-center p-8 text-center">
        <File size={48} className={cn("mb-4", type === 'traditional' ? "text-accent" : "text-secondary")} />
        <p className="text-sm text-white/40 mb-6">Preview available after download</p>
        <a href={url} download={`PDF_Arena_${type}_Result.pdf`} className="w-full">
          <Button variant="outline" className="w-full">Download PDF</Button>
        </a>
      </div>

      {!voted ? (
        <Button 
          variant={type === 'traditional' ? 'accent' : 'secondary'} 
          className="w-full"
          onClick={onVote}
        >
          Vote for this version
        </Button>
      ) : (
        <div className="text-center p-3 rounded-xl bg-white/5 font-bold uppercase tracking-widest text-xs">
          {winner ? 'WINNER' : 'VOTED'}
        </div>
      )}
    </Card>
  );
};

// Re-importing Shield icon as it was used in Setup screen
import { Shield } from 'lucide-react';
