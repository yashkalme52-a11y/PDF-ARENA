import React, { useState } from 'react';
import { Card, Button, cn } from '../components/UI';
import { Check, Zap, Shield, Crown, Infinity, HelpCircle } from 'lucide-react';
import { motion } from 'framer-motion';

const PLANS = [
  {
    name: 'FREE',
    price: '₹0',
    description: 'Perfect for casual users',
    features: ['5 operations/day', '13 basic tools', 'Basic AI analysis', 'Community leaderboard', '2hr file storage'],
    color: 'border-white/10',
    button: 'Current Plan',
    active: true
  },
  {
    name: 'PRO',
    price: '₹299',
    description: 'For power users & pros',
    features: ['Unlimited operations', 'All 18 tools', 'Priority AI (Gemini Pro)', '7 day file storage', 'Batch processing', 'Google Drive sync'],
    color: 'border-primary/50 bg-primary/5',
    button: 'Upgrade to Pro',
    popular: true
  },
  {
    name: 'ENTERPRISE',
    price: 'Custom',
    description: 'For teams & business',
    features: ['Everything in Pro', 'API Access', '25 Team members', 'Custom AI models', 'Dedicated Manager', 'Custom Branding'],
    color: 'border-secondary/50 bg-secondary/5',
    button: 'Contact Sales'
  }
];

export const PricingPage = () => {
  const [isAnnual, setIsAnnual] = useState(false);

  return (
    <div className="pt-32 pb-20 px-6 max-w-7xl mx-auto">
      <div className="text-center mb-16">
        <h2 className="text-5xl font-black mb-4">Choose Your Arena</h2>
        <p className="text-white/40 mb-10">Transparent pricing for every kind of PDF warrior.</p>
        
        <div className="flex items-center justify-center gap-4">
          <span className={cn("text-sm font-bold", !isAnnual ? "text-white" : "text-white/40")}>Monthly</span>
          <button 
            onClick={() => setIsAnnual(!isAnnual)}
            className="w-14 h-7 bg-white/10 rounded-full p-1 transition-all relative"
          >
            <motion.div 
              animate={{ x: isAnnual ? 28 : 0 }}
              className="w-5 h-5 bg-primary rounded-full shadow-[0_0_10px_rgba(99,102,241,0.5)]" 
            />
          </button>
          <span className={cn("text-sm font-bold", isAnnual ? "text-white" : "text-white/40")}>
            Annual <span className="text-success text-[10px] bg-success/10 px-2 py-0.5 rounded-full ml-1">SAVE 20%</span>
          </span>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8 mb-24">
        {PLANS.map((plan, i) => (
          <PricingCard key={plan.name} plan={plan} isAnnual={isAnnual} index={i} />
        ))}
      </div>

      <section className="max-w-3xl mx-auto">
        <h3 className="text-3xl font-bold mb-12 text-center flex items-center justify-center gap-3">
          <HelpCircle className="text-primary" /> Frequently Asked Questions
        </h3>
        <div className="space-y-4">
          <FaqItem question="Is my data safe?" answer="Yes, all files are encrypted and automatically deleted after 2 hours (Free) or 7 days (Pro). We never store your PDF content permanently." />
          <FaqItem question="Can I cancel anytime?" answer="Absolutely. No commitments, no hidden fees. Cancel your Pro subscription from your dashboard with one click." />
          <FaqItem question="How does the AI work?" answer="We use the latest Gemini models to analyze your PDF operations and suggest improvements or generate enhanced versions." />
          <FaqItem question="What tools are 'Pro'?" answer="Advanced tools like OCR, Repair PDF, and Direct PDF to Word conversion are exclusive to Pro and Enterprise users." />
        </div>
      </section>
    </div>
  );
};

const PricingCard = ({ plan, isAnnual, index }: any) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      whileHover={{ scale: 1.02 }}
      className="perspective-1000"
    >
      <Card className={cn("h-full flex flex-col p-8 transition-all duration-500", plan.color)}>
        {plan.popular && (
          <div className="bg-primary text-white text-[10px] font-bold px-3 py-1 rounded-full w-fit mb-6 shadow-lg shadow-primary/20">
            MOST POPULAR
          </div>
        )}
        <div className="text-xl font-bold mb-2">{plan.name}</div>
        <div className="flex items-baseline gap-1 mb-4">
          <span className="text-5xl font-black">{isAnnual && plan.price !== 'Custom' ? `₹${Math.round(parseInt(plan.price.slice(1))*0.8)}` : plan.price}</span>
          {plan.price !== 'Custom' && <span className="text-white/40">/month</span>}
        </div>
        <p className="text-white/40 text-sm mb-8">{plan.description}</p>
        
        <div className="space-y-4 mb-10 flex-grow">
          {plan.features.map((feat: string) => (
            <div key={feat} className="flex items-center gap-3 text-sm">
              <Check className="text-success shrink-0" size={16} />
              <span>{feat}</span>
            </div>
          ))}
        </div>

        <Button 
          variant={plan.popular ? 'primary' : 'outline'} 
          className="w-full h-14"
        >
          {plan.button}
        </Button>
      </Card>
    </motion.div>
  );
};

const FaqItem = ({ question, answer }: any) => {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <Card className="p-0 overflow-hidden">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full p-6 text-left flex justify-between items-center hover:bg-white/5 transition-colors"
      >
        <span className="font-bold">{question}</span>
        <motion.span animate={{ rotate: isOpen ? 180 : 0 }}>
          <Check size={20} className="opacity-20" />
        </motion.span>
      </button>
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ height: 0 }} 
            animate={{ height: 'auto' }} 
            exit={{ height: 0 }}
            className="px-6 pb-6 text-white/50 text-sm"
          >
            {answer}
          </motion.div>
        )}
      </AnimatePresence>
    </Card>
  );
};

import { AnimatePresence } from 'framer-motion';
