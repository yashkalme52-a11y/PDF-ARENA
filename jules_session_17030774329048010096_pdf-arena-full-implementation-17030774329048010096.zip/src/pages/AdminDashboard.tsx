import React from 'react';
import { Card } from '../components/UI';
import { 
  Users, Activity, DollarSign, BarChart3, TrendingUp, 
  ArrowUpRight, ArrowDownRight, Search
} from 'lucide-react';
import { 
  LineChart, Line, AreaChart, Area, PieChart, Pie, Cell, 
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer 
} from 'recharts';

const OPERATIONAL_DATA = Array.from({ length: 30 }, (_, i) => ({
  date: i + 1,
  ops: Math.floor(Math.random() * 5000) + 10000,
  users: Math.floor(Math.random() * 200) + 800,
}));

const TOOL_USAGE = [
  { name: 'Merge', value: 4500 },
  { name: 'Split', value: 3200 },
  { name: 'Compress', value: 2800 },
  { name: 'PDF-Img', value: 2100 },
  { name: 'Other', value: 1500 },
];

const COLORS = ['#6366f1', '#a855f7', '#06b6d4', '#10b981', '#f59e0b'];

import { cn } from '../components/UI';

export const AdminDashboard = () => {
  return (
    <div className="pt-32 pb-20 px-6 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row items-center justify-between mb-12 gap-6">
        <div>
          <h2 className="text-4xl font-black mb-2">Admin Terminal</h2>
          <p className="text-white/40 uppercase tracking-widest text-xs font-bold">System Health & Analytics</p>
        </div>
        <div className="flex gap-4">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-white/20" size={18} />
            <input 
              type="text" 
              placeholder="Search operations..." 
              className="bg-white/5 border border-white/10 rounded-xl pl-12 pr-4 py-2 text-sm focus:ring-1 focus:ring-primary outline-none"
            />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        <AdminStatCard label="Total Users" value="124,502" change="+12.5%" icon={<Users />} />
        <AdminStatCard label="DAU" value="45,210" change="+8.2%" icon={<Activity />} />
        <AdminStatCard label="Monthly Revenue" value="₹1,245,000" change="+24.1%" icon={<DollarSign />} />
        <AdminStatCard label="Total Ops" value="2.4M" change="+18.7%" icon={<BarChart3 />} />
      </div>

      <div className="grid lg:grid-cols-3 gap-8 mb-12">
        <Card className="lg:col-span-2">
          <div className="flex items-center justify-between mb-8">
            <h3 className="font-bold flex items-center gap-2">
              <TrendingUp className="text-success" size={20} /> Operations (Last 30 Days)
            </h3>
            <div className="flex gap-2">
              <div className="px-3 py-1 bg-white/5 rounded-md text-[10px] font-bold">PDF OPS</div>
              <div className="px-3 py-1 bg-primary/20 text-primary border border-primary/20 rounded-md text-[10px] font-bold">USER GROWTH</div>
            </div>
          </div>
          <div className="h-[350px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={OPERATIONAL_DATA}>
                <defs>
                  <linearGradient id="colorOps" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
                <XAxis dataKey="date" stroke="#ffffff20" fontSize={10} tickLine={false} />
                <YAxis stroke="#ffffff20" fontSize={10} tickLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#080810', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px' }}
                />
                <Area type="monotone" dataKey="ops" stroke="#6366f1" fillOpacity={1} fill="url(#colorOps)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card>
          <h3 className="font-bold mb-8">Most Used Tools</h3>
          <div className="h-[250px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={TOOL_USAGE}
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {TOOL_USAGE.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="space-y-3 mt-4">
            {TOOL_USAGE.map((tool, i) => (
              <div key={tool.name} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full" style={{ backgroundColor: COLORS[i] }} />
                  <span className="text-white/60">{tool.name}</span>
                </div>
                <span className="font-bold">{(tool.value / 14100 * 100).toFixed(1)}%</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card className="overflow-hidden p-0">
        <div className="p-6 border-b border-white/5 flex items-center justify-between">
          <h3 className="font-bold">Recent System Logs</h3>
          <div className="text-[10px] uppercase tracking-widest text-success font-black flex items-center gap-2">
            <div className="w-1.5 h-1.5 bg-success rounded-full animate-pulse" />
            Live System Pulse
          </div>
        </div>
        <div className="divide-y divide-white/5">
          {[1,2,3,4,5].map((i) => (
            <div key={i} className="p-4 flex items-center justify-between text-sm hover:bg-white/5 transition-colors">
              <div className="flex items-center gap-4">
                <div className="w-8 h-8 rounded-full bg-success/10 text-success flex items-center justify-center">
                  <Activity size={14} />
                </div>
                <div>
                  <span className="font-bold text-white/80">PDF_MERGE_SUCCESS</span>
                  <span className="text-white/20 mx-3">|</span>
                  <span className="text-white/40">Operation completed in 452ms</span>
                </div>
              </div>
              <div className="text-[10px] text-white/20 font-mono">2026-06-12 14:52:0{i}</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};

const AdminStatCard = ({ label, value, change, icon }: any) => (
  <Card className="p-6">
    <div className="flex justify-between items-start mb-4">
      <div className="w-10 h-10 bg-white/5 rounded-xl flex items-center justify-center text-white/60">
        {React.cloneElement(icon, { size: 20 })}
      </div>
      <div className={cn(
        "flex items-center text-[10px] font-bold px-2 py-0.5 rounded-full",
        change.startsWith('+') ? "bg-success/10 text-success" : "bg-red-500/10 text-red-500"
      )}>
        {change.startsWith('+') ? <ArrowUpRight size={10} className="mr-1" /> : <ArrowDownRight size={10} className="mr-1" />}
        {change}
      </div>
    </div>
    <div className="text-2xl font-black mb-1">{value}</div>
    <div className="text-[10px] text-white/40 uppercase tracking-widest font-bold">{label}</div>
  </Card>
);
