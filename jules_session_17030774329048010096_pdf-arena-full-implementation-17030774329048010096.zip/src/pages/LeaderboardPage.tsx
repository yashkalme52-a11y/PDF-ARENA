import React from 'react';
import { useApp } from '../store/AppContext';
import { Card } from '../components/UI';
import { ToolId } from '../types';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Trophy, Zap, ShieldAlert } from 'lucide-react';
import { motion } from 'framer-motion';

const TOOLS: { id: ToolId, name: string }[] = [
  { id: 'merge', name: 'Merge PDF' },
  { id: 'split', name: 'Split PDF' },
  { id: 'compress', name: 'Compress PDF' },
  { id: 'pdf-to-img', name: 'PDF to Image' },
  { id: 'img-to-pdf', name: 'Image to PDF' },
  { id: 'watermark', name: 'Watermark' },
  { id: 'page-numbers', name: 'Page Numbers' },
  { id: 'rotate', name: 'Rotate PDF' },
  { id: 'protect', name: 'Protect PDF' },
  { id: 'unlock', name: 'Unlock PDF' },
  { id: 'redact', name: 'Redact PDF' },
  { id: 'compare', name: 'Compare PDFs' },
  { id: 'fill-form', name: 'Fill Form' },
];

export const LeaderboardPage = () => {
  const { eloScores, stats } = useApp();

  const data = TOOLS.map(tool => {
    const score = eloScores[tool.id] || { traditional: 1500, ai: 1500 };
    return {
      name: tool.name,
      traditional: score.traditional,
      ai: score.ai,
      gap: score.ai - score.traditional
    };
  });

  const overallWinner = data.reduce((acc, curr) => acc + curr.gap, 0) > 0 ? 'AI Enhanced' : 'Traditional';

  return (
    <div className="pt-32 pb-20 px-6 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row items-center justify-between mb-16 gap-8">
        <div>
          <h2 className="text-5xl font-black mb-4">Live Battle Live</h2>
          <p className="text-white/40">Real-time Elo rankings based on {stats.votesCast} user votes.</p>
        </div>
        
        <Card className="border-primary/30 bg-primary/5 flex items-center gap-6 px-8 py-6">
          <div className="w-16 h-16 rounded-2xl bg-primary/20 flex items-center justify-center">
            <Trophy className="text-primary w-8 h-8" />
          </div>
          <div>
            <div className="text-xs uppercase tracking-widest text-white/40 mb-1">Overall Leader</div>
            <div className="text-3xl font-black text-white">{overallWinner}</div>
          </div>
        </Card>
      </div>

      <div className="grid lg:grid-cols-3 gap-8 mb-16">
        <Card className="lg:col-span-2">
          <h3 className="text-xl font-bold mb-8 flex items-center gap-2">
            <Zap className="text-secondary" /> Elo Comparison per Tool
          </h3>
          <div className="h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data}>
                <XAxis dataKey="name" stroke="#ffffff40" fontSize={10} tick={{ fill: '#ffffff60' }} />
                <YAxis stroke="#ffffff40" domain={[1400, 1650]} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1a1a2e', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px' }}
                  itemStyle={{ color: '#fff' }}
                />
                <Bar dataKey="traditional" fill="#06b6d4" radius={[4, 4, 0, 0]} />
                <Bar dataKey="ai" fill="#a855f7" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <div className="space-y-6">
          <Card>
            <h3 className="font-bold mb-4">Total Votes Cast</h3>
            <div className="text-6xl font-black text-primary">{stats.votesCast.toLocaleString()}</div>
            <p className="text-xs text-white/40 mt-4 tracking-tighter uppercase font-bold">Updated just now</p>
          </Card>
          
          <Card className="border-secondary/20">
            <h3 className="font-bold mb-4">Win Probability</h3>
            <div className="space-y-4">
              <WinBar label="AI Enhanced" percent={54} color="bg-secondary" />
              <WinBar label="Traditional" percent={46} color="bg-accent" />
            </div>
          </Card>
        </div>
      </div>

      <Card className="overflow-hidden">
        <table className="w-full text-left">
          <thead>
            <tr className="border-b border-white/10 bg-white/5">
              <th className="px-6 py-4 font-bold uppercase tracking-widest text-xs opacity-40">Rank</th>
              <th className="px-6 py-4 font-bold uppercase tracking-widest text-xs opacity-40">Tool Name</th>
              <th className="px-6 py-4 font-bold uppercase tracking-widest text-xs opacity-40 text-accent">Traditional Elo</th>
              <th className="px-6 py-4 font-bold uppercase tracking-widest text-xs opacity-40 text-secondary">AI Elo</th>
              <th className="px-6 py-4 font-bold uppercase tracking-widest text-xs opacity-40">Status</th>
            </tr>
          </thead>
          <tbody>
            {data.sort((a, b) => (b.ai + b.traditional) - (a.ai + a.traditional)).map((tool, i) => (
              <tr key={i} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                <td className="px-6 py-4 font-black text-2xl text-white/20">#{(i + 1).toString().padStart(2, '0')}</td>
                <td className="px-6 py-4 font-bold">{tool.name}</td>
                <td className="px-6 py-4 text-accent font-mono">{tool.traditional}</td>
                <td className="px-6 py-4 text-secondary font-mono">{tool.ai}</td>
                <td className="px-6 py-4">
                  {tool.gap > 0 ? (
                    <span className="text-[10px] bg-secondary/20 text-secondary px-2 py-1 rounded-full font-bold">AI DOMINANT</span>
                  ) : (
                    <span className="text-[10px] bg-accent/20 text-accent px-2 py-1 rounded-full font-bold">TRADITIONAL STRONG</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
};

const WinBar = ({ label, percent, color }: any) => (
  <div className="space-y-1">
    <div className="flex justify-between text-xs font-bold uppercase tracking-widest">
      <span>{label}</span>
      <span>{percent}%</span>
    </div>
    <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden">
      <motion.div 
        initial={{ width: 0 }}
        whileInView={{ width: `${percent}%` }}
        className={`h-full ${color}`}
      />
    </div>
  </div>
);
