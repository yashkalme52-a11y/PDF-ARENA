import { PDFDocument } from 'pdf-lib';
import { mergePDFs, rotatePDF, addPageNumbers } from './src/utils/pdfManipulation.js';
import fs from 'fs';

async function verifyAll() {
  const pdfDoc = await PDFDocument.create();
  pdfDoc.addPage([600, 400]).drawText('Test');
  const bytes = await pdfDoc.save();
  
  const merged = await mergePDFs([bytes.buffer, bytes.buffer]);
  console.log('Merge verified:', merged.length > 0);
  
  const rotated = await rotatePDF(bytes.buffer, 90);
  console.log('Rotate verified:', rotated.length > 0);

  const numbered = await addPageNumbers(bytes.buffer, 'bottom-center');
  console.log('Page numbers verified:', numbered.length > 0);
}

// Simple check for existence of files
const filesToCheck = [
  'src/pages/LandingPage.tsx',
  'src/pages/ToolPage.tsx',
  'src/pages/LeaderboardPage.tsx',
  'src/pages/DashboardPage.tsx',
  'src/pages/PricingPage.tsx',
  'src/pages/AdminDashboard.tsx',
  'src/utils/pdfManipulation.ts',
  'src/utils/pdfConversion.ts',
  'src/utils/pdfSecurity.ts',
  'src/store/AppContext.tsx'
];

filesToCheck.forEach(f => {
  if (!fs.existsSync(f)) throw new Error(`Missing file: ${f}`);
});
console.log('All core files present.');

verifyAll().catch(console.error);
